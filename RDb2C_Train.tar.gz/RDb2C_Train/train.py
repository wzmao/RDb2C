# -*- coding: utf-8 -*-

__author__ = 'Wenzhi Mao'

# Load customization functions and options.
# See customization.py for detail
from customization import *

from utilize import *

# Try to Import all libaries we need
# All package we need: multiprocessing, os, numpy, scipy and sklearn.

if use_parallel:
    from multiprocessing import Pool

import os

from numpy import array, unique, load, save, hstack, vstack, zeros, arange, argmax

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
from sklearn.externals import joblib


################### Read Data ###################
print('Parsing data.')
# Parse Train list, you could edit it to use your own list. Detailed
# format is in the `train_list.dat`
f = open('train_list.dat', 'r')
train_content = [i.strip() for i in f if not i.startswith('#') and i.strip()]
f.close()
train_infos = [train_content[i:i+6] for i in range(0, len(train_content), 6)]

# Format the train informations
for i in range(len(train_infos)):
    # Protein length
    train_infos[i][1] = int(train_infos[i][1])
    # Protein sequence
    train_infos[i][2] = train_infos[i][2].replace('\t', '')
    # DSSP secondary structure
    train_infos[i][3] = train_infos[i][3].replace('\t', '')
    # Get the raw pair data
    pair_raw = array([[int(j) for j in line.split()] for line in train_infos[i][4:6]])
    # Check the length consistency
    if not len(train_infos[i][2]) == len(train_infos[i][3]) == pair_raw.shape[1]:
        raise ValueError('Wrong length for training set. Check the input list.')
    # Build the pair array
    x, y = pair_raw.nonzero()
    pair = array([pair_raw[(x, y)]-1, y]).T
    pair.sort(axis=1)
    pair = unique([complex(j[0], j[1]) for j in pair])
    pair.sort()
    pair = array([pair.real, pair.imag]).T.astype(int)
    # Replace the raw pair infomation
    train_infos[i][4] = pair
    train_infos[i] = train_infos[i][:5]



def secondary_to_3_class(sec):
    '''Convert the Q8 to Q3.'''
    for i, j in [['I', 'H'], ['G', 'H'], ['B', 'E'], ['.', 'C'], ['T', 'C'], ['S', 'C']]:
        sec = sec.replace(i, j)
    return sec


# Parse BetaSheet916 list, http://download.igb.uci.edu/betadata/betasheet.dat
f = open('BetaSheet916.dat', 'r')
betasheet916_content = [i.strip() for i in f if not i.startswith('#') and i.strip()]
f.close()
test916_infos = [betasheet916_content[i:i+7] for i in range(0, len(betasheet916_content), 7)]

# Format the BetaSheet916 informations
for i in range(len(test916_infos)):
    # Protein length
    test916_infos[i][1] = int(test916_infos[i][1])
    # Protein sequence
    test916_infos[i][2] = test916_infos[i][2].replace('\t', '')
    # DSSP secondary structure
    test916_infos[i][3] = secondary_to_3_class(test916_infos[i][3].replace('\t', ''))
    # Get the raw pair data
    pair_raw = array([[int(j) for j in line.split()] for line in test916_infos[i][4:6]])
    # Check the length consistency
    if not len(test916_infos[i][2]) == len(test916_infos[i][3]) == pair_raw.shape[1]:
        raise ValueError('Wrong length for training set. Check the input list.')
    # Build the pair array
    x, y = pair_raw.nonzero()
    pair = array([pair_raw[(x, y)]-1, y]).T
    pair.sort(axis=1)
    pair = unique([complex(j[0], j[1]) for j in pair])
    pair.sort()
    pair = array([pair.real, pair.imag]).T.astype(int)
    # Replace the raw pair infomation
    test916_infos[i][4] = pair
    test916_infos[i] = test916_infos[i][:5]



# Parse BetaSheet1452 list, http://biocomp.unibo.it/savojard/bcov/BetaSheet1452.dat
f = open('BetaSheet1452.dat', 'r')
betasheet1452_content = [i.strip() for i in f if not i.startswith('#') and i.strip()]
f.close()
test1452_infos = [betasheet1452_content[i:i+6] for i in range(0, len(betasheet1452_content), 6)]

# Format the BetaSheet1452 informations
for i in range(len(test1452_infos)):
    # Protein name
    test1452_infos[i][0] = test1452_infos[i][0].replace('_', '')
    # Protein length
    test1452_infos[i][1] = int(test1452_infos[i][1])
    # Protein sequence, the BetaSheet1452 labeld disulfide bond as lower case
    test1452_infos[i][2] = ''.join([j if not j.islower() else 'C' for j in test1452_infos[i][2].split('\t')])
    # DSSP secondary structure
    test1452_infos[i][3] = secondary_to_3_class(test1452_infos[i][3].replace('\t', ''))
    # Get the raw pair data
    pair_raw = array([[int(j) for j in line.split()] for line in test1452_infos[i][4:6]])
    # Check the length consistency
    if not len(test1452_infos[i][2]) == len(test1452_infos[i][3]) == pair_raw.shape[1]:
        raise ValueError('Wrong length for training set. Check the input list.')
    # Build the pair array
    x, y = pair_raw.nonzero()
    pair = array([pair_raw[(x, y)]-1, y]).T
    pair.sort(axis=1)
    pair = unique([complex(j[0], j[1]) for j in pair])
    pair.sort()
    pair = array([pair.real, pair.imag]).T.astype(int)
    # Replace the raw pair infomation
    test1452_infos[i][4] = pair
    test1452_infos[i] = test1452_infos[i][:5]





################### Get Raw Contact Maps and Predicted Secondary Structure ###################

def mkdir(dir):
    '''Make directory if the directory doesn't exists'''
    from os import mkdir as osmkdir
    from os.path import exists
    if not exists(dir):
        osmkdir(dir)

print('Building raw matrix and predicted secondary structure.')
# Build Train set data
mkdir("01_train_raw")
mkdir("01_train_raw/map")
mkdir("01_train_raw/secondary")
mkdir("01_train_raw/seqnum")


def prepare1(x):
    protein_name, resnum, seq, dssp, pair = x

    matrix_ok = False
    if os.path.exists("01_train_raw/map/{}.npy".format(protein_name)) and load("01_train_raw/map/{}.npy".format(protein_name)).shape == (resnum, resnum):
        matrix_ok = True
    else:
        raw_matrix = get_matrix(seq, name=protein_name)
        if raw_matrix is not None:
            save("01_train_raw/map/{}.npy".format(protein_name), raw_matrix)
            matrix_ok = True

    secondary_ok = False
    if os.path.exists("01_train_raw/secondary/{}.npy".format(protein_name)) and load("01_train_raw/secondary/{}.npy".format(protein_name)).shape == (resnum, 3):
        secondary_ok = True
    else:
        predicted_secondary = get_secondary(seq, dssp=dssp)
        if predicted_secondary is not None:
            save("01_train_raw/secondary/{}.npy".format(protein_name), predicted_secondary)
            secondary_ok = True

    seqnum_ok = False
    if os.path.exists("01_train_raw/seqnum/{}.npy".format(protein_name)) and load("01_train_raw/seqnum/{}.npy".format(protein_name)).shape == (resnum, 3):
        seqnum_ok = True
    else:
        seqnum = get_seqnum(seq)
        if seqnum is not None:
            save("01_train_raw/seqnum/{}.npy".format(protein_name), seqnum)
            seqnum_ok = True

    return matrix_ok and secondary_ok and seqnum_ok

if use_parallel:
    pool = Pool()
    result = pool.map(prepare1, train_infos)
    pool.close()
    pool.join()
else:
    result = map(prepare1, train_infos)

if not all(result):
    raise ValueError("Couldn't build all cases in train set.")


# Build test set data
mkdir("02_test_raw")
mkdir("02_test_raw/map")
mkdir("02_test_raw/secondary")
mkdir("02_test_raw/seqnum")

# Build BetaSheet916 set data
mkdir("02_test_raw/map/916")
mkdir("02_test_raw/secondary/916")
mkdir("02_test_raw/seqnum/916")


def prepare2(x):
    protein_name, resnum, seq, dssp, pair = x

    matrix_ok = False
    if os.path.exists("02_test_raw/map/916/{}.npy".format(protein_name)) and load("02_test_raw/map/916/{}.npy".format(protein_name)).shape == (resnum, resnum):
        matrix_ok = True
    else:
        raw_matrix = get_matrix(seq, name=protein_name)
        if raw_matrix is not None:
            save("02_test_raw/map/916/{}.npy".format(protein_name), raw_matrix)
            matrix_ok = True

    secondary_ok = False
    if os.path.exists("02_test_raw/secondary/916/{}.npy".format(protein_name)) and load("02_test_raw/secondary/916/{}.npy".format(protein_name)).shape == (resnum, 3):
        secondary_ok = True
    else:
        predicted_secondary = get_secondary(seq, dssp=dssp)
        if predicted_secondary is not None:
            save("02_test_raw/secondary/916/{}.npy".format(protein_name), predicted_secondary)
            secondary_ok = True

    seqnum_ok = False
    if os.path.exists("02_test_raw/seqnum/916/{}.npy".format(protein_name)) and load("02_test_raw/seqnum/916/{}.npy".format(protein_name)).shape == (resnum, 3):
        seqnum_ok = True
    else:
        seqnum = get_seqnum(seq)
        if seqnum is not None:
            save("02_test_raw/seqnum/916/{}.npy".format(protein_name), seqnum)
            seqnum_ok = True

    return matrix_ok and secondary_ok and seqnum_ok

if use_parallel:
    pool = Pool()
    result = pool.map(prepare2, test916_infos)
    pool.close()
    pool.join()
else:
    result = map(prepare2, test916_infos)

if not all(result):
    raise ValueError("Couldn't build all cases in BetaSheet916 set.")


# Build BetaSheet1452 set data
mkdir("02_test_raw/map/1452")
mkdir("02_test_raw/secondary/1452")
mkdir("02_test_raw/seqnum/1452")


def prepare3(x):
    protein_name, resnum, seq, dssp, pair = x

    matrix_ok = False
    if os.path.exists("02_test_raw/map/1452/{}.npy".format(protein_name)) and load("02_test_raw/map/1452/{}.npy".format(protein_name)).shape == (resnum, resnum):
        matrix_ok = True
    else:
        raw_matrix = get_matrix(seq, name=protein_name)
        if raw_matrix is not None:
            save("02_test_raw/map/1452/{}.npy".format(protein_name), raw_matrix)
            matrix_ok = True

    secondary_ok = False
    if os.path.exists("02_test_raw/secondary/1452/{}.npy".format(protein_name)) and load("02_test_raw/secondary/1452/{}.npy".format(protein_name)).shape == (resnum, 3):
        secondary_ok = True
    else:
        predicted_secondary = get_secondary(seq, dssp=dssp)
        if predicted_secondary is not None:
            save("02_test_raw/secondary/1452/{}.npy".format(protein_name), predicted_secondary)
            secondary_ok = True

    seqnum_ok = False
    if os.path.exists("02_test_raw/seqnum/1452/{}.npy".format(protein_name)) and load("02_test_raw/seqnum/1452/{}.npy".format(protein_name)).shape == (resnum, 3):
        seqnum_ok = True
    else:
        seqnum = get_seqnum(seq)
        if seqnum is not None:
            save("02_test_raw/seqnum/1452/{}.npy".format(protein_name), seqnum)
            seqnum_ok = True

    return matrix_ok and secondary_ok and seqnum_ok

if use_parallel:
    pool = Pool()
    result = pool.map(prepare3, test1452_infos)
    pool.close()
    pool.join()
else:
    result = map(prepare3, test1452_infos)

if not all(result):
    raise ValueError("Couldn't build all cases in BetaSheet1452 set.")






################### Build fetures for train set ###################

print('Building features.')

mkdir('03_features')


def buildfeatures(x):

    from numpy import concatenate

    protein_name, resnum, seq, dssp, pair = x

    if os.path.exists('03_features/{}.npy'.format(protein_name)):
        if load('03_features/{}.npy'.format(protein_name)).shape == (resnum, resnum, 2):
            return

    # Get ridge features
    ridgefeature = buildRidgeFeature(
        load('01_train_raw/map/{}.npy'.format(protein_name)))

    save('03_features/{}.npy'.format(protein_name), ridgefeature)


if use_parallel:
    pool = Pool()
    result = pool.map(buildfeatures, train_infos)
    pool.close()
    pool.join()
else:
    result = map(buildfeatures, train_infos)





################### Train the model ###################

############## 1st stage ##############

print('Training the Model')

mkdir('04_1st_stage')


def getdata1(case, getall=40, ws=None):

    from numpy import zeros, concatenate, newaxis, random, arange, ones, indices

    pair = train_infos[case][4]
    rawmap = load('01_train_raw/map/{}.npy'.format(train_infos[case][0]))
    predicted_secondary = load('01_train_raw/secondary/{}.npy'.format(train_infos[case][0]))
    seqnum = load('01_train_raw/seqnum/{}.npy'.format(train_infos[case][0]))
    resnum = train_infos[case][1]
    seq = train_infos[case][2]

    extendsize = (ws-1)//2

    xchange = arange(-extendsize, extendsize + 1)[newaxis, :, newaxis]+zeros(ws, dtype=int)[newaxis, newaxis, :]
    ychange = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+zeros(ws, dtype=int)[newaxis, :, newaxis]

    if not len(train_infos[case][2]) == len(train_infos[case][3]) == resnum == len(predicted_secondary):
        raise ValueError("Seq and secondary does not fit.")

    if rawmap.shape != (resnum, resnum):
        raise ValueError("Wrong map shape")

    ylabel = zeros((resnum, resnum))
    ylabel[pair[:, 0], pair[:, 1]] = ylabel[pair[:, 1], pair[:, 0]] = 1

    features = load('03_features/{}.npy'.format(train_infos[case][0]))

    feature_2d = concatenate((features, rawmap[:, :, newaxis]), 2)

    if getall is not True:
        posindex = array((ylabel != 0).nonzero())
        negindex = array((ylabel == 0).nonzero())
        negindex = negindex[:, random.choice(arange(negindex.shape[1]), size=(posindex.shape[1]*getall), replace=False)]
        combineindex = hstack((posindex, negindex))
    else:
        combineindex = indices((resnum, resnum))
        combineindex.resize((2, resnum**2))
    mask = 1
    xchange, ychange = xchange[abs(abs(xchange)-abs(ychange)) <= mask][newaxis, :], ychange[abs(abs(xchange)-abs(ychange)) <= mask][newaxis, :]
    xx, yy = xchange+combineindex[0][:, newaxis], ychange+combineindex[1][:, newaxis]
    xx[xx >= resnum] = -1
    yy[yy >= resnum] = -1
    featurefeed_2d = feature_2d[xx, yy].copy()
    featurefeed_2d[(xx < 0)+(yy < 0)] = 0
    featurefeed_2d.resize((featurefeed_2d.shape[0], array(featurefeed_2d.shape[1:]).cumprod()[-1]))
    labelfeed = ylabel[(combineindex[0], combineindex[1])]
    ind = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+combineindex.T[:, :, newaxis]
    ind[ind >= resnum] = -1
    secfeature = predicted_secondary[ind]
    secfeature[(ind < 0)] = 0
    secfeature.resize((secfeature.shape[0], array(secfeature.shape[1:]).cumprod()[-1]))
    casefeature = ones((len(secfeature), 2)) * array([1.*seqnum/resnum, rawmap.std()])
    posdiff = abs(combineindex[0]-combineindex[1])[:, newaxis]
    edge = array([combineindex[0], resnum-1-combineindex[0], combineindex[1], resnum-1-combineindex[1]]).T
    featurefeed = hstack((featurefeed_2d, secfeature, casefeature, posdiff, edge))
    return featurefeed, labelfeed


model = RandomForestClassifier(n_estimators=500, n_jobs=-1)
kf = KFold(n_splits=5, shuffle=True, random_state=1)
cutoff1 = zeros(4)

# Build modles for different window size
for ws in [3, 5, 7, 9]:
    mkdir('04_1st_stage/ws_{}'.format(ws))

    print('Training the 1st stage model: window size={}'.format(ws))

    mkdir('04_1st_stage/ws_{}/Cross-validation'.format(ws))
    # Check if all cross validation is done
    if len(os.listdir('04_1st_stage/ws_{}/Cross-validation'.format(ws))) == len(train_infos):
        pass
    else:
        # Old job need to start again
        for i in os.listdir('04_1st_stage/ws_{}/Cross-validation'.format(ws)):
            os.remove(os.path.join('04_1st_stage/ws_{}/Cross-validation'.format(ws), i))
        # Cross validation
        for train_index, test_index in kf.split(range(len(train_infos))):
            X_train = []
            y_train = []
            for i in train_index:
                temp = getdata1(i, getall=40, ws=ws)
                X_train.append(temp[0])
                y_train.append(temp[1])
            X_train = vstack(X_train)
            y_train = hstack(y_train)
            model.fit(X_train, y_train)

            for i in test_index:
                testfeature, testlabel = getdata1(i, getall=True, ws=ws)
                predicted = model.predict_proba(testfeature)[:, 1]
                save('04_1st_stage/ws_{}/Cross-validation/{}.npy'.format(ws, train_infos[i][0]), predicted)
    # Whole model
    if not os.path.exists('04_1st_stage/ws_{0}/1st-{0}x{0}.gz'.format(ws)):
        X = []
        y = []
        for i in range(len(train_infos)):
            temp = getdata1(i, getall=40, ws=ws)
            X.append(temp[0])
            y.append(temp[1])
        X = vstack(X)
        y = hstack(y)
        model.fit(X, y)
        joblib.dump(model, '04_1st_stage/ws_{0}/1st-{0}x{0}.gz'.format(ws), compress=3)

    # Get the best cutoff from the cross-validation.
    if not os.path.exists('04_1st_stage/ws_{}/Cross-validation'.format(ws)):
        raise ValueError("There is no directory.")
    if len(os.listdir('04_1st_stage/ws_{}/Cross-validation'.format(ws))) != len(train_infos):
        raise ValueError("There is missing results.")
    reallabel = []
    predicted = []
    for i in range(len(train_infos)):
        pair = train_infos[i][4]
        label = zeros((train_infos[i][1], train_infos[i][1]))
        label[pair[:, 0], pair[:, 1]] = label[pair[:, 1], pair[:, 0]] = 1
        pred = load('04_1st_stage/ws_{}/Cross-validation/{}.npy'.format(ws, train_infos[i][0]))
        pred.resize(label.shape)
        pred = (pred+pred.T)/2.
        reallabel.append(label.ravel())
        predicted.append(pred.ravel())
    reallabel = hstack(reallabel)
    predicted = hstack(predicted)
    f = []
    cutoffsearch = arange(0, 1, .005)
    for i in cutoffsearch:
        tp = reallabel[predicted > i].sum()
        realp = reallabel.sum()
        foundp = (predicted > i).sum()
        f.append([1.*tp/foundp if foundp != 0 else 0, 1.*tp/realp if realp !=0 else 0, 2.*tp/(realp+foundp) if (realp+foundp) != 0 else 0.])
    f = array(f)
    bestindex = argmax(f[:, 2])
    print("Cross validation result: cutoff={}, Precision={:.2f}%, Recall={:.2f}%, F1-score={:.2f}%".format(cutoffsearch[bestindex], f[bestindex, 0]*100, f[bestindex, 1]*100, f[bestindex, 2]*100))
    cutoff1[ws//2-1] = cutoffsearch[bestindex]


############## 2nd stage ##############

mkdir('05_2nd_stage')


def getdata2(case, getall=40):

    from numpy import zeros, concatenate, newaxis, random, arange, ones, indices, empty_like, sort, stack

    pair = train_infos[case][4]
    rawmap = load('01_train_raw/map/{}.npy'.format(train_infos[case][0]))
    predicted_secondary = load('01_train_raw/secondary/{}.npy'.format(train_infos[case][0]))
    seqnum = load('01_train_raw/seqnum/{}.npy'.format(train_infos[case][0]))
    resnum = train_infos[case][1]
    seq = train_infos[case][2]

    extendsize = (3-1)//2

    xchange = arange(-extendsize, extendsize + 1)[newaxis, :, newaxis]+zeros(3, dtype=int)[newaxis, newaxis, :]
    ychange = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+zeros(3, dtype=int)[newaxis, :, newaxis]

    if not len(train_infos[case][2]) == len(train_infos[case][3]) == resnum == len(predicted_secondary):
        raise ValueError("Seq and secondary does not fit.")

    if rawmap.shape != (resnum, resnum):
        raise ValueError("Wrong map shape")

    ylabel = zeros((resnum, resnum))
    ylabel[pair[:, 0], pair[:, 1]] = ylabel[pair[:, 1], pair[:, 0]] = 1

    features = []
    for ws in [3, 5, 7, 9]:
        temp = load('04_1st_stage/ws_{}/Cross-validation/{}.npy'.format(ws, train_infos[case][0]))
        if temp.size != resnum**2:
            raise ValueError("Wrong size")
        temp = temp.reshape((resnum, resnum))
        temp = (temp+temp.T)/2.
        a = empty_like(temp)
        for i in range(len(a)):
            st = sort(temp[i])
            a[i] = st.searchsorted(temp[i], side='right')
        a = len(a)-a
        b = empty_like(temp)
        for i in range(len(b)):
            st = sort(temp[:, i])
            b[:, i] = st.searchsorted(temp[:, i], side='right')
        b = len(b)-b
        features.append(temp)
        features.append(a)
        features.append(b)
    features = stack(features, -1)

    features = concatenate((features, load('03_features/{}.npy'.format(train_infos[case][0]))), 2)

    if getall is not True:
        posindex = array((ylabel != 0).nonzero())
        negindex = array((ylabel == 0).nonzero())
        negindex = negindex[:, random.choice(arange(negindex.shape[1]), size=(posindex.shape[1]*getall), replace=False)]
        combineindex = hstack((posindex, negindex))
    else:
        combineindex = indices((resnum, resnum))
        combineindex.resize((2, resnum**2))
    xx, yy = xchange+combineindex[0][:, newaxis, newaxis], ychange+combineindex[1][:, newaxis, newaxis]
    xx[xx >= resnum] = -1
    yy[yy >= resnum] = -1
    featurefeed_2d = features[xx, yy]
    featurefeed_2d[(xx < 0)+(yy < 0)] = 0
    featurefeed_2d.resize((featurefeed_2d.shape[0], array(featurefeed_2d.shape[1:]).cumprod()[-1]))
    labelfeed = ylabel[(combineindex[0], combineindex[1])]
    ind = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+combineindex.T[:, :, newaxis]
    ind[ind >= resnum] = -1
    secfeature = predicted_secondary[ind]
    secfeature[(ind < 0)] = 0
    secfeature.resize((secfeature.shape[0], array(secfeature.shape[1:]).cumprod()[-1]))
    featurefeed = hstack((secfeature, featurefeed_2d))
    return featurefeed, labelfeed


# Build modles for different window size

print('Training the 2nd stage model')

mkdir('05_2nd_stage/Cross-validation')
# Check if all cross validation is done
if len(os.listdir('05_2nd_stage/Cross-validation')) == len(train_infos):
    pass
else:
    # Old job need to start again
    for i in os.listdir('05_2nd_stage/Cross-validation'):
        os.remove(os.path.join('05_2nd_stage/Cross-validation', i))
    # Cross validation
    for train_index, test_index in kf.split(range(len(train_infos))):
        X_train = []
        y_train = []
        for i in train_index:
            temp = getdata2(i, getall=40)
            X_train.append(temp[0])
            y_train.append(temp[1])
        X_train = vstack(X_train)
        y_train = hstack(y_train)
        model.fit(X_train, y_train)

        for i in test_index:
            testfeature, testlabel = getdata2(i, getall=True)
            predicted = model.predict_proba(testfeature)[:, 1]
            predicted = (predicted+predicted.T)/2
            save('05_2nd_stage/Cross-validation/{}.npy'.format(train_infos[i][0]), predicted)
# Whole model
if not os.path.exists('05_2nd_stage/2nd.gz'):
    X = []
    y = []
    for i in range(len(train_infos)):
        temp = getdata2(i, getall=40)
        X.append(temp[0])
        y.append(temp[1])
    X = vstack(X)
    y = hstack(y)
    model.fit(X, y)
    joblib.dump(model, '05_2nd_stage/2nd.gz', compress=3)

# Get the best cutoff from the cross-validation.
if not os.path.exists('05_2nd_stage/Cross-validation'):
    raise ValueError("There is no directory.")
if len(os.listdir('05_2nd_stage/Cross-validation')) != len(train_infos):
    raise ValueError("There is missing results.")
reallabel = []
predicted = []
for i in range(len(train_infos)):
    pair = train_infos[i][4]
    label = zeros((train_infos[i][1], train_infos[i][1]))
    label[pair[:, 0], pair[:, 1]] = label[pair[:, 1], pair[:, 0]] = 1
    pred = load('05_2nd_stage/Cross-validation/{}.npy'.format(train_infos[i][0]))
    pred.resize(label.shape)
    reallabel.append(label.ravel())
    predicted.append(pred.ravel())
reallabel = hstack(reallabel)
predicted = hstack(predicted)
f = []
cutoffsearch = arange(0, 1, .005)
for i in cutoffsearch:
    tp = reallabel[predicted > i].sum()
    realp = reallabel.sum()
    foundp = (predicted > i).sum()
    f.append([1.*tp/foundp if foundp != 0 else 0, 1.*tp/realp if realp !=0 else 0, 2.*tp/(realp+foundp) if (realp+foundp) != 0 else 0.])
f = array(f)
bestindex = argmax(f[:, 2])
print("Cross validation result: cutoff={}, Precision={:.2f}%, Recall={:.2f}%, F1-score={:.2f}%".format(cutoffsearch[bestindex], f[bestindex, 0]*100, f[bestindex, 1]*100, f[bestindex, 2]*100))
cutoff2 = cutoffsearch[bestindex]


############## 3rd stage ##############

mkdir('06_3rd_stage')


def getdata3(case, getall=40):

    from numpy import zeros, concatenate, newaxis, random, arange, ones, indices, empty_like, sort, stack

    pair = train_infos[case][4]
    rawmap = load('01_train_raw/map/{}.npy'.format(train_infos[case][0]))
    predicted_secondary = load('01_train_raw/secondary/{}.npy'.format(train_infos[case][0]))
    seqnum = load('01_train_raw/seqnum/{}.npy'.format(train_infos[case][0]))
    resnum = train_infos[case][1]
    seq = train_infos[case][2]

    extendsize = (3-1)//2

    xchange = arange(-extendsize, extendsize + 1)[newaxis, :, newaxis]+zeros(3, dtype=int)[newaxis, newaxis, :]
    ychange = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+zeros(3, dtype=int)[newaxis, :, newaxis]

    if not len(train_infos[case][2]) == len(train_infos[case][3]) == resnum == len(predicted_secondary):
        raise ValueError("Seq and secondary does not fit.")

    if rawmap.shape != (resnum, resnum):
        raise ValueError("Wrong map shape")

    ylabel = zeros((resnum, resnum))
    ylabel[pair[:, 0], pair[:, 1]] = ylabel[pair[:, 1], pair[:, 0]] = 1

    features = []
    temp = load('05_2nd_stage/Cross-validation/{}.npy'.format(train_infos[case][0]))
    if temp.size != resnum**2:
        raise ValueError("Wrong size")
    temp = temp.reshape((resnum, resnum))
    temp = (temp+temp.T)/2.
    a = empty_like(temp)
    for i in range(len(a)):
        st = sort(temp[i])
        a[i] = st.searchsorted(temp[i], side='right')
    a = len(a)-a
    b = empty_like(temp)
    for i in range(len(b)):
        st = sort(temp[:, i])
        b[:, i] = st.searchsorted(temp[:, i], side='right')
    b = len(b)-b
    features.append(temp)
    features.append(a)
    features.append(b)
    features = stack(features, -1)

    features = concatenate((features, load('03_features/{}.npy'.format(train_infos[case][0]))), 2)

    if getall is not True:
        posindex = array((ylabel != 0).nonzero())
        negindex = array((ylabel == 0).nonzero())
        negindex = negindex[:, random.choice(arange(negindex.shape[1]), size=(posindex.shape[1]*getall), replace=False)]
        combineindex = hstack((posindex, negindex))
    else:
        combineindex = indices((resnum, resnum))
        combineindex.resize((2, resnum**2))
    xx, yy = xchange+combineindex[0][:, newaxis, newaxis], ychange+combineindex[1][:, newaxis, newaxis]
    xx[xx >= resnum] = -1
    yy[yy >= resnum] = -1
    featurefeed_2d = features[xx, yy]
    featurefeed_2d[(xx < 0)+(yy < 0)] = 0
    featurefeed_2d.resize((featurefeed_2d.shape[0], array(featurefeed_2d.shape[1:]).cumprod()[-1]))
    labelfeed = ylabel[(combineindex[0], combineindex[1])]
    ind = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+combineindex.T[:, :, newaxis]
    ind[ind >= resnum] = -1
    secfeature = predicted_secondary[ind]
    secfeature[(ind < 0)] = 0
    secfeature.resize((secfeature.shape[0], array(secfeature.shape[1:]).cumprod()[-1]))
    featurefeed = hstack((secfeature, featurefeed_2d))
    return featurefeed, labelfeed


# Build final modle

print('Training the 3rd stage model')

mkdir('06_3rd_stage/Cross-validation')
# Check if all cross validation is done
if len(os.listdir('06_3rd_stage/Cross-validation')) == len(train_infos):
    pass
else:
    # Old job need to start again
    for i in os.listdir('06_3rd_stage/Cross-validation'):
        os.remove(os.path.join('06_3rd_stage/Cross-validation', i))
    # Cross validation
    for train_index, test_index in kf.split(range(len(train_infos))):
        X_train = []
        y_train = []
        for i in train_index:
            temp = getdata3(i, getall=40)
            X_train.append(temp[0])
            y_train.append(temp[1])
        X_train = vstack(X_train)
        y_train = hstack(y_train)
        model.fit(X_train, y_train)

        for i in test_index:
            testfeature, testlabel = getdata3(i, getall=True)
            predicted = model.predict_proba(testfeature)[:, 1]
            predicted = (predicted+predicted.T)/2
            save('06_3rd_stage/Cross-validation/{}.npy'.format(train_infos[i][0]), predicted)
# Whole model
if not os.path.exists('06_3rd_stage/3rd.gz'):
    X = []
    y = []
    for i in range(len(train_infos)):
        temp = getdata3(i, getall=40)
        X.append(temp[0])
        y.append(temp[1])
    X = vstack(X)
    y = hstack(y)
    model.fit(X, y)
    joblib.dump(model, '06_3rd_stage/3rd.gz', compress=3)

# Get the best cutoff from the cross-validation.
if not os.path.exists('06_3rd_stage/Cross-validation'):
    raise ValueError("There is no directory.")
if len(os.listdir('06_3rd_stage/Cross-validation')) != len(train_infos):
    raise ValueError("There is missing results.")
reallabel = []
predicted = []
for i in range(len(train_infos)):
    pair = train_infos[i][4]
    label = zeros((train_infos[i][1], train_infos[i][1]))
    label[pair[:, 0], pair[:, 1]] = label[pair[:, 1], pair[:, 0]] = 1
    pred = load('06_3rd_stage/Cross-validation/{}.npy'.format(train_infos[i][0]))
    pred.resize(label.shape)
    reallabel.append(label.ravel())
    predicted.append(pred.ravel())
reallabel = hstack(reallabel)
predicted = hstack(predicted)
f = []
cutoffsearch = arange(0, 1, .005)
for i in cutoffsearch:
    tp = reallabel[predicted > i].sum()
    realp = reallabel.sum()
    foundp = (predicted > i).sum()
    f.append([1.*tp/foundp if foundp != 0 else 0, 1.*tp/realp if realp !=0 else 0, 2.*tp/(realp+foundp) if (realp+foundp) != 0 else 0.])
f = array(f)
bestindex = argmax(f[:, 2])
print("Cross validation result: cutoff={}, Precision={:.2f}%, Recall={:.2f}%, F1-score={:.2f}%".format(cutoffsearch[bestindex], f[bestindex, 0]*100, f[bestindex, 1]*100, f[bestindex, 2]*100))
cutoff3 = cutoffsearch[bestindex]




################### Make package ###################

print('Building package.')

mkdir("{}".format(package_name))
mkdir("{0}/{0}".format(package_name))
mkdir("{0}/{0}/Models".format(package_name))
f = open('{0}/{0}/__init__.py'.format(package_name), 'w')
f.write(r'''# -*- coding: utf-8 -*-
__author__ = 'Wenzhi Mao'
__version__ = '0.0.1'

__release__ = [int(x) for x in __version__.split('.')]
__all__ = []

from platform import system
from sys import version_info

_system = system()

_PY3K = version_info[0] > 2
_PY2K = not _PY3K

if _PY2K:
    del x
del version_info
del system

from . import IO
from .IO import *
__all__.extend(IO.__all__)
__all__.append('IO')

from . import Prediction
from .Prediction import *
__all__.extend(Prediction.__all__)
__all__.append('Prediction')


def _Integrity_check(deepcheck=False):
    """Test if all model exists."""
    from os.path import join, exists

    models_path = join(__path__[0], 'Models')

    for i in [3, 5, 7, 9]:
        if not exists(join(models_path, "1st-{0}x{0}.gz".format(i))):
            raise ValueError("There are missing models.")
    if not exists(join(models_path, "2nd.gz")):
        raise ValueError("There are missing models.")
    if not exists(join(models_path, "3rd.gz")):
        raise ValueError("There are missing models.")
    if deepcheck:
        from sklearn.externals import joblib
        for i in [3, 5, 7, 9]:
            joblib.load(join(models_path, "1st-{0}x{0}.gz".format(i)))
        joblib.load(join(models_path, "2nd.gz"))
        joblib.load(join(models_path, "3rd.gz"))

_Integrity_check(deepcheck=False)
''')
f.close()
f = open('{0}/{0}/IO.py'.format(package_name), 'w')
f.write(r"""# -*- coding: utf-8 -*-

__author__ = 'Wenzhi Mao'
__all__ = ['parseCCMpred', 'parseDeepCNF', 'parsePSIPRED', 'parseDSSP',
            'parseFasta', 'parseRaptorX', 'parseRaptorXSeqnum']


def parseCCMpred(file):
    '''Parse CCMPred result. The `file` could be file path, file content or
    file stream.'''

    if isinstance(file, str):
        from os.path import exists
        if exists(file):
            from numpy import loadtxt
            mat = loadtxt(file)
        else:
            from numpy import array
            lines = [[float(i) for i in line.strip().split()]
                     for line in file.strip().split('\n')]
            if len(set([len(i) for i in lines])) != 1:
                raise ValueError('The number in each line is not the same.')
            mat = array(lines)
    elif 'read' in dir(file):
        from numpy import array
        lines = [[float(i) for i in line.strip().split()]
                 for line in file.read().strip().split('\n')]
        if len(set([len(i) for i in lines])) != 1:
            raise ValueError('The number in each line is not the same.')
        mat = array(lines)
    else:
        raise ValueError('Cannot recognize the CCMPred.')

    if mat.ndim != 2:
        raise ValueError('The CCMPred dimension is wrong.')
    if mat.shape[0] != mat.shape[1]:
        raise ValueError('The CCMPred shape is not square.')
    mat = (mat+mat.T)/2.
    return mat


def parseDeepCNF(file):
    '''Parse DeepCNF result. The `file` could be file path, file content or
    file stream.'''

    from numpy import array

    if isinstance(file, str):
        from os.path import exists
        if exists(file):
            f = open(file, 'r')
            lines = [line.strip() for line in f.read().strip().split('\n')]
            f.close()
        else:
            lines = [line.strip() for line in file.strip().split('\n')]
    elif 'read' in dir(file):
        lines = [line.strip() for line in file.read().strip().split('\n')]
    else:
        raise ValueError('Cannot recognize the DeepCNF.')

    lines = [line for line in lines if not line.startswith('#')]
    lines = [line for line in lines if line]
    lines = [[float(i) for i in line.split()[-3:]] for line in lines]
    if any([len(i) != 3 for i in lines]):
        raise ValueError('The DeepCNF data should be Nx3 shape.')
    deepcnf = array(lines)
    return deepcnf


def parsePSIPRED(file):
    '''Parse PSIPRED result. The `file` could be file path, file content or
    file stream.'''

    from numpy import array, zeros

    if isinstance(file, str):
        from os.path import exists
        if exists(file):
            f = open(file, 'r')
            psipredraw = f.read().strip().split('\n')[1]
            f.close()
        else:
            psipredraw = file.strip().split('\n')[1]
    elif 'read' in dir(file):
        psipredraw = file.read().strip().split('\n')[1]
    else:
        raise ValueError('Cannot recognize the PSIPRED.')

    psipredraw = [{'H': 0, 'E': 1, 'C': 2}[i] for i in list(psipredraw)]
    psipred = zeros((len(psipredraw), 3))
    psipred[range(len(psipredraw)), psipredraw] = 1
    return psipred


def parseDSSP(file):
    '''Parse PSIPRED result. The `file` could be file path, file content or
    file stream.'''

    from numpy import zeros
    from operator import itemgetter

    if isinstance(file, str):
        from os.path import exists
        if exists(file):
            f = open(file, 'r')
            for line in f:
                if line.startswith('  #  RESIDUE'):
                    break
            dsspraw = [[i[11], int(i[5:10]), i[10].strip(), i[
                16].strip()] for i in f]
            f.close()
        else:
            num = 0
            while not file.strip().split('\n')[num].startswith('  #  RESIDUE'):
                num += 1
            dsspraw = [[i[11], int(i[5:10]), i[10].strip(), i[16].strip()]
                       for i in file.strip().split('\n')[num+1:]]
    elif 'read' in dir(file):
        for line in file:
            if line.startswith('  #  RESIDUE'):
                break
        dsspraw = [[i[11], int(i[5:10]), i[10].strip(), i[
            16].strip()] for i in file]
    else:
        raise ValueError('Cannot recognize the PSIPRED.')

    dsspraw = sorted(dsspraw, key=itemgetter(0, 1, 2))
    dsspraw = [{'H': 0, 'I': 0, 'G': 0, 'B': 1, 'E': 1, 'T': 2,
                'S': 2, 'C': 2, '': 2, }[i[3]] for i in dsspraw]
    dssp = zeros((len(dsspraw), 3))
    dssp[range(len(dsspraw)), dsspraw] = 1
    return dssp


def parseFasta(file):
    '''Parse Fasta sequence. The `file` could be file path, file content or
    file stream.
    Only the first sequence will be parsed.'''

    if isinstance(file, str):
        from os.path import exists
        if exists(file):
            f = open(file, 'r')
            for line in f:
                if not line.startswith('>'):
                    break
            sequence = line
            f.close()
        else:
            num = 0
            while file.strip().split('\n')[num].startswith('>'):
                num += 1
            sequence = file.strip().split('\n')[num]
    elif 'read' in dir(file):
        for line in file:
            if not line.startswith('>'):
                break
        sequence = line
    else:
        raise ValueError('Cannot recognize the Fasta file.')

    return sequence.strip()

def parseRaptorX(file):
    '''Parse RaptorX-Contact result. The `file` could be file path'''

    from os.path import exists
    from numpy import loadtxt
    import zipfile

    if exists(file):
        f=zipfile.ZipFile(file)
        cf=[i for i in f.filelist if i.filename.find('.gcnn')!=-1]
        if len(cf)!=1:
            raise ValueError("More than 1 gcnn in the file.")
        cf=cf[0]
        ff=f.open(cf)
        matrix=loadtxt(ff)
    else:
        raise ValueError("File path doesn't exist.")

    return matrix

def parseRaptorXSeqnum(file):
    '''Parse RaptorX-Contact result. The `file` could be file path'''

    from os.path import exists
    from numpy import loadtxt
    import zipfile

    if exists(file):
        f=zipfile.ZipFile(file)
        cf=[i for i in f.filelist if i.filename.find('.a2m')!=-1]
        if len(cf)!=1:
            raise ValueError("More than 1 gcnn in the file.")
        cf=cf[0]
        ff=f.open(cf)
        seqnum=sum([1 for i in ff])
    else:
        raise ValueError("File path doesn't exist.")

    return seqnum
""")
f.close()
f = open('{0}/{0}/Prediction.py'.format(package_name), 'w')
f.write(r"""# -*- coding: utf-8 -*-

__author__ = 'Wenzhi Mao'
__all__ = ['buildRidgeFeature', 'buildPrediction', 'getAllModels']


def removeDiag(matrix, diag_remove):
    '''Shrink the matrix from diagonal.'''

    from numpy import array, zeros, tril_indices, triu_indices

    newm = zeros(array(matrix.shape)-diag_remove-1, dtype=matrix.dtype)
    n = matrix.shape[0]
    newm[tril_indices(newm.shape[0])] = matrix[tril_indices(n, -diag_remove-1)]
    newm[triu_indices(newm.shape[0], 1)] = matrix[triu_indices(n, diag_remove+2)]
    return newm


def buildRidgeFeature(image):
    '''Build the ridge feature matrix from image(like CCMpred). Input is a 
    NxN matrix. The shape of output matrix is NxNx8.'''

    from numpy import arange, zeros, empty, array, ones, newaxis, stack
    from numpy import zeros_like, transpose, ones_like, argmax, indices
    from numpy import arccos, triu_indices, tril_indices, geterr, seterr
    from numpy import inf, pi

    from numpy.linalg import inv, norm

    from scipy import ndimage

    err=geterr()
    seterr(all = 'ignore')
    sigmas = arange(1, 3.1, .1)
    searchsize = 2

    # Build the matrix with diagnal removed
    oldimage = image.copy()
    image = removeDiag(image, 0)

    # Build empty matrixs
    sigmal = len(sigmas)
    shape = list(image.shape)
    m = zeros([sigmal]+list(shape))
    newshape = list(m.shape)
    infos = empty(newshape+[8], dtype=float)
    lamda = empty(newshape+[2], dtype=float)
    eigv = empty(newshape+[2, 2], dtype=float)
    topoint = empty(newshape+[2, 2], dtype=float)

    # Build Convolve matrixs
    index = array(ones((searchsize*2+1, searchsize*2+1)).nonzero())
    tempinfo = empty((index.shape[1], 6), dtype=float)
    tempinfo[:, 0] = 1.
    tempinfo[:, 1] = index[0]-(searchsize)
    tempinfo[:, 2] = index[1]-(searchsize)
    tempinfo[:, 3] = 0.5*tempinfo[:, 1]**2
    tempinfo[:, 4] = 0.5*tempinfo[:, 2]**2
    tempinfo[:, 5] = tempinfo[:, 1]*tempinfo[:, 2]
    tempinfo = ((inv(tempinfo.T.dot(tempinfo)).dot(tempinfo.T)))
    tempinfo.resize(6, searchsize*2+1, searchsize*2+1)
    # Convolve need the filter to be inversed
    tempinfo = tempinfo[:, ::-1, ::-1]

    # Calculate Convolved matrixs
    for i, s in enumerate(sigmas):
        m[i] = ndimage.gaussian_filter(image, s, mode='mirror')
        for j in range(1, 6):
            infos[i, :, :, j - 1] = ndimage.convolve(m[i], tempinfo[j], mode='nearest')
        infos[i, :, :, 5] = infos[i, :, :, 2]+infos[i, :, :, 3]  # xx+yy
        infos[i, :, :, 6] = infos[i, :, :, 2]-infos[i, :, :, 3]  # xx-yy
        infos[i, :, :, 7] = 2 * infos[i, :, :, 4]                # 2xy
        lamda[i, :, :, 0] = (infos[i, :, :, 5]-(infos[i, :, :, 6]**2+infos[i, :, :, 7]**2)**.5)/2
        lamda[i, :, :, 1] = (infos[i, :, :, 5]+(infos[i, :, :, 6]**2+infos[i, :, :, 7]**2)**.5)/2
        temp = ((lamda[i, :, :]-infos[i, :, :, 3:4])/infos[i, :, :, 4:5])
        eigv[i, :, :, 0, :] = temp/(temp**2+1)**.5
        eigv[i, :, :, 1, :] = 1./(temp**2+1)**.5
        A = eigv[i, :, :, :, :1]*lamda[i, :, :, 0][:, :, newaxis, newaxis]
        A.resize(shape+[2])
        b = -(eigv[i, :, :, :, 0]*infos[i, :, :, :2]).sum(2)
        topoint[i, :, :, 1, 0] = A[:, :, 1]
        topoint[i, :, :, 1, 1] = -A[:, :, 0]
        tonorm = norm(topoint[i, :, :, 1], axis=2, keepdims=True)
        tonorm[tonorm == 0] = 1
        topoint[i, :, :, 1] /= tonorm
        temp = stack((A, topoint[i, :, :, 1]), 2)
        temp[norm(topoint[i, :, :, 1], axis=2) != 0] = inv(temp[norm(topoint[i, :, :, 1], axis=2) != 0])
        temp1 = stack((b, zeros_like(b)), 2)
        temp1.resize(list(temp1.shape)+[1])
        topoint[i, :, :, 0] = (temp*transpose(temp1, (0, 1, 3, 2))).sum(3)
        topoint[i, norm(topoint[i, :, :, 1], axis=2) == 0, 0] = inf

    topoint[topoint[:, :, :, 1, 1] < 0, 1] *= -1

    # Basic filter: close to ridge and is ridge
    closeok = ((topoint[:, :, :, 0]**2).sum(3) < 2)*(lamda[:, :, :, 0] < 0)

    mask = ones_like(image)
    masks = []
    results = []
    errors = infos[[slice(None, None)]+list(mask.nonzero()) + [slice(5, 8)]].std(axis=1, ddof=1)**2
    strength = (infos[:, :, :, 5:8]**2).clip(min=0)
    strength[closeok == False] = 0
    strength = strength[:, :, :, 0]*(strength[:, :, :, 1] + strength[:, :, :, 2])*(sigmas[:, newaxis, newaxis]**6.)
    argm = argmax(strength, axis=0)
    xind, yind = indices(argm.shape)
    width = sigmas[argm]
    deg = topoint[argm, xind, yind, 1].copy()
    deg[deg[:, :, 1] < 0] *= -1
    deg = arccos(deg[:, :, 0].clip(min=-1, max=1))/pi*180

    height = (strength[argm, xind, yind]*64*width**2)**.25

    feature = stack((height, deg), axis=-1)
    feature[feature[:, :, 0] == 0, 1] = 0

    finalfeature = zeros(list(oldimage.shape)+[feature.shape[2]])
    finalfeature[tril_indices(finalfeature.shape[0], -1)] = feature[tril_indices(feature.shape[0], 0)]
    finalfeature[triu_indices(finalfeature.shape[0], 1)] = feature[triu_indices(feature.shape[0], 0)]

    seterr(divide=err['divide'], over=err['over'], under=err['under'], invalid=err['invalid'])
    return finalfeature


_models = [[None for i in range(4)], None, None]


def getModel(stage, windowsize=None):
    '''Load specific model into memory.'''

    from . import __path__
    from os.path import join
    from sklearn.externals import joblib

    global _models

    # clearModel()
    if stage not in [1, 2, 3]:
        raise ValueError('stage must be 1, 2 or 3.')
    if stage == 1:
        if windowsize not in [3, 5, 7, 9]:
            raise ValueError("Wrong ratio or windowsize.")
        if _models[0][windowsize//2-1] is None:
            _models[0][windowsize//2-1] = joblib.load(join(__path__[0], 'Models', "1st-{0}x{0}.gz".format(windowsize)))
        return _models[0][windowsize//2-1]
    elif stage == 2:
        if _models[1] is None:
            _models[1] = joblib.load(join(__path__[0], 'Models', "2nd.gz"))
        return _models[1]
    elif stage == 3:
        if _models[2] is None:
            _models[2] = joblib.load(join(__path__[0], 'Models', "3rd.gz"))
        return _models[2]


def getAllModels():
    '''Load all model into memory which would accelerate the speed for batch test.'''

    for windowsize in [3, 5, 7, 9]:
        getModel(1, windowsize)
    getModel(2)
    getModel(3)


def clearModel():
    global _models
    import gc
    _models = [[None for i in range(4)], None, None]
    gc.collect()


def buildPrediction(matrix, secondary, seq, seqnum, memorysavemode=False, cutoff=None):
    '''Build prediction from matrix, secondary infomation and sequence and sequence number.
    the sequence number could get from the RaptorX-Contact zip result in default.
    `memorysavemode` option allow you to enable the memory save mode, default is False.
    `cutoff` option could be `residue` or None. It will clip the result at suggested cutoff.
    '''

    from numpy import ndarray, concatenate, newaxis, indices, arange, zeros
    from numpy import cumprod, ones, hstack, empty_like, sort, stack
    # from .IO import parseRaptorXSeqnum, parseRaptorX, parseDeepCNF, parseFasta
    from time import time

    try:
        seqnum=int(seqnum)
    except:
        raise ValueError('seqnum must be integer.')
    if not isinstance(matrix, ndarray):
        raise ValueError('Matrix must be numpy.array.')
    if not isinstance(secondary, ndarray):
        raise ValueError('Secondary structure must be numpy.array.')
    try:
        seq = str(seq)
    except:
    	raise ValueError('seq must be string.')

    if matrix.ndim != 2:
        raise ValueError('Matrix must be 2D matrix.')
    if matrix.shape[0] != matrix.shape[1]:
        raise ValueError('Matrix must be square.')
    if secondary.ndim != 2:
        raise ValueError('Secondary information must be 2D matrix.')
    if secondary.shape[1] != 3:
        raise ValueError('Secondary information must be Nx3 matrix.')
    if not matrix.shape[0] == matrix.shape[1] == secondary.shape[0] == len(seq):
        raise ValueError(
            "Matrix, secondary info and sequence residue number must be consistent.")

    if not memorysavemode:
        starttime = time()
        print("* Parsing Models...")
        getAllModels()
        print("* Models parsed in {:.2f} seconds.".format(time()-starttime))
    else:
        print("* Memory save mode enabled.")
        clearModel()

    starttime = time()
    print("* Performaing prediction...")

    resnum = len(seq)
    ridgeinfo = buildRidgeFeature(matrix)
    matrixinfo = concatenate((ridgeinfo, matrix[:, :, newaxis]), axis=2)

    combineindex = indices((resnum, resnum))
    combineindex.resize((2, resnum**2))

    firststage = []
    for windowsize in [3, 5, 7, 9]:

        extendsize = (windowsize-1)//2
        xchange = arange(-extendsize, extendsize+1)[newaxis, :, newaxis]+zeros(2*extendsize+1, dtype=int)[newaxis, newaxis, :]
        ychange = arange(-extendsize, extendsize+1)[newaxis, newaxis, :]+zeros(2*extendsize+1, dtype=int)[newaxis, :, newaxis]
        mask = 1
        xchange, ychange = xchange[abs(abs(xchange)-abs(ychange)) <= mask][newaxis, :], ychange[abs(abs(xchange)-abs(ychange)) <= mask][newaxis, :]
        xx, yy = xchange+combineindex[0][:,newaxis], ychange+combineindex[1][:, newaxis]
        xx[xx >= resnum] = -1
        yy[yy >= resnum] = -1
        ridgefeature = matrixinfo[xx, yy].copy()
        ridgefeature[(xx < 0)+(yy < 0)] = 0
        ridgefeature.resize((ridgefeature.shape[0], cumprod(ridgefeature.shape[1:])[-1]))

        ind = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+combineindex.T[:, :, newaxis]
        ind[ind >= resnum] = -1
        secfeature = secondary[ind].copy()
        secfeature[(ind < 0)] = 0
        secfeature.resize((secfeature.shape[0], cumprod(secfeature.shape[1:])[-1]))

        pointfeature = ones((len(combineindex[0]), 7))
        pointfeature[:, 0] = 1.*seqnum/resnum
        pointfeature[:, 1] = matrix.std()
        pointfeature[:, 2] = abs(combineindex[0]-combineindex[1])
        pointfeature[:, 3] = combineindex[0]
        pointfeature[:, 4] = resnum-1-combineindex[0]
        pointfeature[:, 5] = combineindex[1]
        pointfeature[:, 6] = resnum-1-combineindex[1]

        allfeature = hstack((ridgefeature, secfeature, pointfeature)).copy()

        model = getModel(1, windowsize)
        result = model.predict_proba(allfeature)[:, 1]
        if memorysavemode:
            clearModel()

        result = result.reshape((resnum, resnum))
        result = (result+result.T)/2.
        a = empty_like(result)
        for i in range(len(a)):
            st = sort(result[i])
            a[i] = st.searchsorted(result[i], side='right')
        a = len(a)-a
        b = empty_like(result)
        for i in range(len(b)):
            st = sort(result[:, i])
            b[:, i] = st.searchsorted(result[:, i], side='right')
        b = len(b)-b
        firststage.append(stack((result, a, b), axis=2))

    extendsize = 1

    ind = arange(-extendsize, extendsize + 1)[newaxis, newaxis, :]+combineindex.T[:, :, newaxis]
    ind[ind >= resnum] = -1
    secfeature = secondary[ind].copy()
    secfeature[(ind < 0)] = 0
    secfeature.resize((secfeature.shape[0], cumprod(secfeature.shape[1:])[-1]))

    firststagefeature = concatenate(firststage+[ridgeinfo], 2)
    xchange = arange(-extendsize, extendsize+1)[newaxis, :, newaxis]+zeros(2*extendsize+1, dtype=int)[newaxis, newaxis, :]
    ychange = arange(-extendsize, extendsize+1)[newaxis, newaxis, :]+zeros(2*extendsize+1, dtype=int)[newaxis, :, newaxis]
    xx, yy = xchange+combineindex[0][:, newaxis, newaxis], ychange+combineindex[1][:, newaxis, newaxis]
    xx[xx >= resnum] = -1
    yy[yy >= resnum] = -1
    firststagefeature = firststagefeature[xx, yy]
    firststagefeature[(xx < 0)+(yy < 0)] = 0
    firststagefeature.resize((firststagefeature.shape[0], cumprod(firststagefeature.shape[1:])[-1]))

    allfeature = hstack((secfeature, firststagefeature)).copy()

    model = getModel(2)
    result = model.predict_proba(allfeature)[:, 1]
    if memorysavemode:
        clearModel()

    result = result.reshape((resnum, resnum))
    result = (result+result.T)/2.
    a = empty_like(result)
    for i in range(len(a)):
        st = sort(result[i])
        a[i] = st.searchsorted(result[i], side='right')
    a = len(a)-a
    b = empty_like(result)
    for i in range(len(b)):
        st = sort(result[:, i])
        b[:, i] = st.searchsorted(result[:, i], side='right')
    b = len(b)-b
    secondstage = stack((result, a, b), axis=2)

    secondstagefeature = concatenate([secondstage, ridgeinfo], 2)
    xchange = arange(-extendsize, extendsize+1)[newaxis, :, newaxis]+zeros(2*extendsize+1, dtype=int)[newaxis, newaxis, :]
    ychange = arange(-extendsize, extendsize+1)[newaxis, newaxis, :]+zeros(2*extendsize+1, dtype=int)[newaxis, :, newaxis]
    xx, yy = xchange+combineindex[0][:, newaxis, newaxis], ychange+combineindex[1][:, newaxis, newaxis]
    xx[xx >= resnum] = -1
    yy[yy >= resnum] = -1
    secondstagefeature = secondstagefeature[xx, yy]
    secondstagefeature[(xx < 0)+(yy < 0)] = 0
    secondstagefeature.resize((secondstagefeature.shape[0], cumprod(secondstagefeature.shape[1:])[-1]))

    allfeature = hstack((secfeature, secondstagefeature)).copy()

    model = getModel(3)
    thirdstage = model.predict_proba(allfeature)[:, 1]
    if memorysavemode:
        clearModel()

    thirdstage = thirdstage.reshape((resnum, resnum))
    thirdstage = (thirdstage+thirdstage.T)/2.

    print("* Prediction compeleted in {:.2f} seconds.\n".format(time()-starttime))
    if cutoff is 'residue':
        thirdstage[thirdstage <= """+str(cutoff3)+"""] = 0
    return thirdstage
""")
f.close()

for ws in [3, 5, 7, 9]:
    os.popen('cp 04_1st_stage/ws_{0}/1st-{0}x{0}.gz {1}/{1}/Models/'.format(ws, package_name))
os.popen('cp 05_2nd_stage/2nd.gz {0}/{0}/Models/'.format(package_name))
os.popen('cp 06_3rd_stage/3rd.gz {0}/{0}/Models/'.format(package_name))


os.sys.path.append(os.path.abspath(package_name))
package = __import__(package_name)



################### Build Test ###################

print("Testing")

mkdir('07_test_result')

mkdir('07_test_result/916')

tp = 0
foundp = 0
realp = 0

for i in range(len(test916_infos)):
    matrix = load('02_test_raw/map/916/{}.npy'.format(test916_infos[i][0]))
    secondary = load(
        '02_test_raw/secondary/916/{}.npy'.format(test916_infos[i][0]))
    seqnum = load('02_test_raw/seqnum/916/{}.npy'.format(test916_infos[i][0]))
    seq = test916_infos[i][2]
    if os.path.exists('07_test_result/916/{}.npy'.format(test916_infos[i][0])):
        result=load('07_test_result/916/{}.npy'.format(test916_infos[i][0]))
    else:
        result = package.Prediction.buildPrediction(matrix, secondary, seq, seqnum=seqnum, memorysavemode=False, cutoff=None)
        save('07_test_result/916/{}.npy'.format(test916_infos[i][0]),result)
    result=result>cutoff3
    pair = test916_infos[i][4]
    realp += len(pair)*2
    foundp += result.sum()
    tp += result[pair[:, 0], pair[:, 1]].sum()+result[pair[:, 1], pair[:, 0]].sum()
print("BetaSheet916:")
print("Precision={:.2f}%, Recall={:.2f}%, F1-score={:.2f}%".format(100.*tp/foundp if foundp!=0 else 0.,100.*tp/realp,200.*tp/(realp+foundp)))

mkdir('07_test_result/1452')

tp = 0
foundp = 0
realp = 0

for i in range(len(test1452_infos)):
    matrix = load('02_test_raw/map/1452/{}.npy'.format(test1452_infos[i][0]))
    secondary = load(
        '02_test_raw/secondary/1452/{}.npy'.format(test1452_infos[i][0]))
    seqnum = load('02_test_raw/seqnum/1452/{}.npy'.format(test1452_infos[i][0]))
    seq = test1452_infos[i][2]
    if os.path.exists('07_test_result/1452/{}.npy'.format(test1452_infos[i][0])):
        result=load('07_test_result/1452/{}.npy'.format(test1452_infos[i][0]))
    else:
        result = package.Prediction.buildPrediction(matrix, secondary, seq, seqnum=seqnum, memorysavemode=False, cutoff=None)
        save('07_test_result/1452/{}.npy'.format(test1452_infos[i][0]),result)
    result=result>cutoff3
    pair = test1452_infos[i][4]
    realp += len(pair)*2
    foundp += result.sum()
    tp += result[pair[:, 0], pair[:, 1]].sum()+result[pair[:, 1], pair[:, 0]].sum()
print("BetaSheet1452:")
print("Precision={:.2f}%, Recall={:.2f}%, F1-score={:.2f}%".format(100.*tp/foundp if foundp!=0 else 0.,100.*tp/realp,200.*tp/(realp+foundp)))
