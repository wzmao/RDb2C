# -*- coding: utf-8 -*-

__author__ = 'Wenzhi Mao'


def removeDiag(matrix, diag_remove):
	'''Shrink the matrix from diagonal.'''

	from numpy import array, zeros, tril_indices, triu_indices

	newm = zeros(array(matrix.shape)-diag_remove-1, dtype=matrix.dtype)
	n = matrix.shape[0]
	newm[tril_indices(newm.shape[0])] = matrix[tril_indices(n, -diag_remove-1)]
	newm[triu_indices(newm.shape[0], 1)] = matrix[triu_indices(n, diag_remove+2)]
	return newm


def buildRidgeFeature(image):
	'''Build the ridge feature matrix from image(like CCMpred). Input is a 
	NxN matrix. The shape of output matrix is NxNx8.'''

	from numpy import arange, zeros, empty, array, ones, newaxis, stack
	from numpy import zeros_like, transpose, ones_like, argmax, indices
	from numpy import arccos, triu_indices, tril_indices, geterr, seterr
	from numpy import inf, pi

	from numpy.linalg import inv, norm

	from scipy import ndimage

	err=geterr()
	seterr(all = 'ignore')
	sigmas = arange(1, 3.1, .1)
	searchsize = 2

	# Build the matrix with diagnal removed
	oldimage = image.copy()
	image = removeDiag(image, 0)

	# Build empty matrixs
	sigmal = len(sigmas)
	shape = list(image.shape)
	m = zeros([sigmal]+list(shape))
	newshape = list(m.shape)
	infos = empty(newshape+[8], dtype=float)
	lamda = empty(newshape+[2], dtype=float)
	eigv = empty(newshape+[2, 2], dtype=float)
	topoint = empty(newshape+[2, 2], dtype=float)

	# Build Convolve matrixs
	index = array(ones((searchsize*2+1, searchsize*2+1)).nonzero())
	tempinfo = empty((index.shape[1], 6), dtype=float)
	tempinfo[:, 0] = 1.
	tempinfo[:, 1] = index[0]-(searchsize)
	tempinfo[:, 2] = index[1]-(searchsize)
	tempinfo[:, 3] = 0.5*tempinfo[:, 1]**2
	tempinfo[:, 4] = 0.5*tempinfo[:, 2]**2
	tempinfo[:, 5] = tempinfo[:, 1]*tempinfo[:, 2]
	tempinfo = ((inv(tempinfo.T.dot(tempinfo)).dot(tempinfo.T)))
	tempinfo.resize(6, searchsize*2+1, searchsize*2+1)
	# Convolve need the filter to be inversed
	tempinfo = tempinfo[:, ::-1, ::-1]

	# Calculate Convolved matrixs
	for i, s in enumerate(sigmas):
		m[i] = ndimage.gaussian_filter(image, s, mode='mirror')
		for j in range(1, 6):
			infos[i, :, :, j - 1] = ndimage.convolve(m[i], tempinfo[j], mode='nearest')
		infos[i, :, :, 5] = infos[i, :, :, 2]+infos[i, :, :, 3]  # xx+yy
		infos[i, :, :, 6] = infos[i, :, :, 2]-infos[i, :, :, 3]  # xx-yy
		infos[i, :, :, 7] = 2 * infos[i, :, :, 4]                # 2xy
		lamda[i, :, :, 0] = (infos[i, :, :, 5]-(infos[i, :, :, 6]**2+infos[i, :, :, 7]**2)**.5)/2
		lamda[i, :, :, 1] = (infos[i, :, :, 5]+(infos[i, :, :, 6]**2+infos[i, :, :, 7]**2)**.5)/2
		temp = ((lamda[i, :, :]-infos[i, :, :, 3:4])/infos[i, :, :, 4:5])
		eigv[i, :, :, 0, :] = temp/(temp**2+1)**.5
		eigv[i, :, :, 1, :] = 1./(temp**2+1)**.5
		A = eigv[i, :, :, :, :1]*lamda[i, :, :, 0][:, :, newaxis, newaxis]
		A.resize(shape+[2])
		b = -(eigv[i, :, :, :, 0]*infos[i, :, :, :2]).sum(2)
		topoint[i, :, :, 1, 0] = A[:, :, 1]
		topoint[i, :, :, 1, 1] = -A[:, :, 0]
		tonorm = norm(topoint[i, :, :, 1], axis=2, keepdims=True)
		tonorm[tonorm == 0] = 1
		topoint[i, :, :, 1] /= tonorm
		temp = stack((A, topoint[i, :, :, 1]), 2)
		temp[norm(topoint[i, :, :, 1], axis=2) != 0] = inv(temp[norm(topoint[i, :, :, 1], axis=2) != 0])
		temp1 = stack((b, zeros_like(b)), 2)
		temp1.resize(list(temp1.shape)+[1])
		topoint[i, :, :, 0] = (temp*transpose(temp1, (0, 1, 3, 2))).sum(3)
		topoint[i, norm(topoint[i, :, :, 1], axis=2) == 0, 0] = inf

	topoint[topoint[:, :, :, 1, 1] < 0, 1] *= -1

	# Basic filter: close to ridge and is ridge
	closeok = ((topoint[:, :, :, 0]**2).sum(3) < 2)*(lamda[:, :, :, 0] < 0)

	mask = ones_like(image)
	masks = []
	results = []
	errors = infos[[slice(None, None)]+list(mask.nonzero()) + [slice(5, 8)]].std(axis=1, ddof=1)**2
	strength = (infos[:, :, :, 5:8]**2).clip(min=0)
	strength[closeok == False] = 0
	strength = strength[:, :, :, 0]*(strength[:, :, :, 1] + strength[:, :, :, 2])*(sigmas[:, newaxis, newaxis]**6.)
	argm = argmax(strength, axis=0)
	xind, yind = indices(argm.shape)
	width = sigmas[argm]
	deg = topoint[argm, xind, yind, 1].copy()
	deg[deg[:, :, 1] < 0] *= -1
	deg = arccos(deg[:, :, 0].clip(min=-1, max=1))/pi*180

	height = (strength[argm, xind, yind]*64*width**2)**.25

	feature = stack((height, deg), axis=-1)
	feature[feature[:, :, 0] == 0, 1] = 0

	finalfeature = zeros(list(oldimage.shape)+[feature.shape[2]])
	finalfeature[tril_indices(finalfeature.shape[0], -1)] = feature[tril_indices(feature.shape[0], 0)]
	finalfeature[triu_indices(finalfeature.shape[0], 1)] = feature[triu_indices(feature.shape[0], 0)]

	seterr(divide=err['divide'], over=err['over'], under=err['under'], invalid=err['invalid'])
	return finalfeature

