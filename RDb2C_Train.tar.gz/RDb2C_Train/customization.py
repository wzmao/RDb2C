# -*- coding: utf-8 -*-

__author__ = 'Wenzhi Mao'

# Option to use parallel to accelerate the calculation
use_parallel = True


# Name your package name
package_name = "RDb2C_test"


def get_matrix(sequence, *args, **kwargs):
    '''Get the raw matrix from sequence or other input.
    Here, we use real contact map as demonstration.
    Replace the function by your contact prediction method.
    Return should be a NxN numpy array.
    '''

    import requests
    from numpy import array, zeros
    from numpy.linalg import norm

    protein_name = kwargs['name']

    r = requests.get('http://files.rcsb.org/view/{}.pdb'.format(protein_name[:4].upper()))
    c = [i.strip() for i in r.content.split('\n')]
    atoms = [i for i in c if (i.startswith('ATOM') or i.startswith('HETATM')) and i[21] == protein_name[4]]
    ca = [i for i in atoms if i[12:16].strip() == 'CA']
    ca = [i for i in ca if i[17:20].strip() not in ['HOH', 'MG', 'GLC', 'FRU']]
    caid = array([i[22:27] for i in ca])
    ca = [ca[i] for i in range(len(ca)) if (caid[i] == caid[:i]).sum() == 0]
    l2l = {"ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C", "GLU": "E", "GLN": "Q", "GLY": "G", "HIS": "H", "ILE": "I",
           "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P", "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V", }
    restype = ''.join([l2l.get(i[17:20].strip(), 'X') for i in ca])
    if restype.find(sequence) == -1:
        # For test sets, some case are not consistent with PDB.
        if len(restype) == len(sequence):
            pos = [[i[30:38], i[38:46], i[46:54]] for i in ca]
            pos = array([[float(j) for j in i] for i in pos])
            matrix = zeros((len(sequence), len(sequence)))
            for i in range(len(sequence)):
                for j in range(i+1, len(sequence)):
                    matrix[i, j] = matrix[j, i] = 1./norm(pos[i]-pos[j])
            return matrix
        else:
            p = q = 0
            chooseca = []
            while not (p >= len(sequence) or q >= len(restype)):
                if sequence[p] == restype[q]:
                    chooseca.append(ca[q])
                    p += 1
                    q += 1
                else:
                    q += 1
            if len(chooseca) == len(sequence):
                pos = [[i[30:38], i[38:46], i[46:54]] for i in chooseca]
                pos = array([[float(j) for j in i] for i in pos])
                matrix = zeros((len(sequence), len(sequence)))
                for i in range(len(sequence)):
                    for j in range(i+1, len(sequence)):
                        matrix[i, j] = matrix[j, i] = 1./norm(pos[i]-pos[j])
                return matrix
            else:
                print protein_name
                print sequence
                print restype
                return None
    else:
        ca = ca[restype.find(sequence):][:len(sequence)]
        pos = [[i[30:38], i[38:46], i[46:54]] for i in ca]
        pos = array([[float(j) for j in i] for i in pos])
        matrix = zeros((len(sequence), len(sequence)))
        for i in range(len(sequence)):
            for j in range(i+1, len(sequence)):
                matrix[i, j] = matrix[j, i] = 1./norm(pos[i]-pos[j])
        return matrix


def get_secondary(sequence, *args, **kwargs):
    '''Get the predicted secondary structure from sequence or other input.
    Here, we use real DSSP as demonstration.
    Replace the function by your secondary structure prediction method.
    Return should be a Nx3 numpy array for H, E and C.
    '''

    from numpy import array, zeros

    dssp = kwargs['dssp']

    prediction = zeros((len(sequence), 3))
    dssp = array(list(dssp))
    prediction[dssp == 'H', 0] = 1.
    prediction[dssp == 'E', 1] = 1.
    prediction[dssp == 'C', 2] = 1.
    return prediction


def get_seqnum(sequence, *args, **kwargs):
    '''Get the sequence from sequence or other input.
    Here, we use resnum as demonstration.
    Replace the function by your number of sequences in MSA.
    '''

    return len(sequence)